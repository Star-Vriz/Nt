# PSAS - Aplikasi Web Autentikasi (Login & Logout)

PHP native + MySQL + Tailwind CSS (CDN).

## Struktur
```
PSAS_NamaSiswa/
├── index.php
├── koneksi.php
├── login.php
├── dashboard.php
├── logout.php
└── database/db_psas_smk.sql
```

## Cara Menjalankan
1. Start Apache dan MySQL di XAMPP.
2. Salin folder ke `C:\xampp\htdocs\` (ganti `NamaSiswa` dengan namamu).
3. phpMyAdmin -> tab **Import** -> pilih `database/db_psas_smk.sql`.
4. Buka `http://localhost/PSAS_NamaSiswa/`.

## Akun
| Username | Password | Role  |
|----------|----------|-------|
| admin    | admin123 | Admin |
| user     | user123  | User  |

Butuh internet (Tailwind CDN dan Google Fonts).
