<?php
$koneksi = mysqli_connect("localhost", "root", "", "db_psas_smk");
