<?php
session_start();
if (!empty($_SESSION['id_user'])) {
    header("Location: dashboard.php");
    exit;
}
if (isset($_POST['tombol'])) {
    include 'koneksi.php';
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = mysqli_prepare($koneksi, "SELECT * FROM tb_users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // cocok dengan password biasa maupun password yang di-hash
    if ($row && ($password === $row['password'] || password_verify($password, $row['password']))) {
        $_SESSION['id_user']      = $row['id_user'];
        $_SESSION['username']     = $row['username'];
        $_SESSION['nama_lengkap'] = $row['nama_lengkap'];
        $_SESSION['role']         = $row['role'];
        header("Location: dashboard.php");
        exit;
    } else {
        echo "<script>alert('Login Gagal, Username / Password Salah')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap" rel="stylesheet">
<title>Login - Aplikasi Web Autentikasi</title>
<style>
body{font-family:'Sora',system-ui,sans-serif;background:#0b1530;color:#e0f2fe}
.sky{position:fixed;inset:0;z-index:-1;background:radial-gradient(ellipse at 20% 0%,#1e3a6e 0%,transparent 55%),radial-gradient(ellipse at 90% 100%,#16407a 0%,transparent 50%),linear-gradient(160deg,#0b1530,#10254d 60%,#0d1b3d)}
.dot{position:fixed;border-radius:50%;background:#e0f2fe;z-index:-1;animation:twinkle 3s ease-in-out infinite}
.shoot{position:fixed;width:130px;height:2px;border-radius:2px;background:linear-gradient(90deg,rgba(186,230,253,0),#f0f9ff);box-shadow:0 0 8px #bae6fd;opacity:0;z-index:-1;animation:shoot 7s linear infinite}
@keyframes twinkle{0%,100%{opacity:.2}50%{opacity:.9}}
@keyframes shoot{0%{transform:translate(0,0) rotate(30deg);opacity:0}3%{opacity:1}14%{transform:translate(520px,300px) rotate(30deg);opacity:0}100%{transform:translate(520px,300px) rotate(30deg);opacity:0}}
@keyframes rise{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
@keyframes wave{0%,100%{transform:rotate(0)}25%{transform:rotate(20deg)}75%{transform:rotate(-15deg)}}
@keyframes glow{0%,100%{box-shadow:0 0 0 0 rgba(125,211,252,0)}50%{box-shadow:0 0 28px 2px rgba(125,211,252,.25)}}
.rise{animation:rise .8s ease both}
.glow{animation:glow 4s ease-in-out infinite}
.wave{display:inline-block;transform-origin:70% 70%;animation:wave 2s ease-in-out infinite}
@media (prefers-reduced-motion:reduce){*{animation:none!important}}
</style>
</head>
<body class="min-h-screen overflow-x-hidden">
<div class="sky"></div>
<div id="stars"></div>
<i class="shoot" style="top:6%;left:8%;animation-delay:1s"></i>
<i class="shoot" style="top:18%;left:45%;animation-delay:4s;animation-duration:9s"></i>
<i class="shoot" style="top:2%;left:70%;animation-delay:7s;animation-duration:8s"></i>

<div class="min-h-screen flex items-center justify-center p-4">
  <form method="post" action="#" class="rise glow w-full max-w-sm bg-white/[0.06] backdrop-blur-md border border-white/15 rounded-2xl p-7">
    <div class="mx-auto mb-3 w-14 h-14 rounded-xl bg-gradient-to-br from-sky-300 to-blue-500 flex items-center justify-center shadow-lg shadow-sky-500/30">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0b1530" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5"/><path d="M9 7h6"/></svg>
    </div>
    <h4 class="text-center text-2xl font-extrabold text-sky-100">Login</h4>
    <h5 class="text-center text-sm text-sky-300/80 mb-6">Aplikasi Web Autentikasi</h5>
    <input name="username" placeholder="Username" required class="w-full bg-white/10 border border-white/15 rounded-lg px-4 py-2.5 mb-3 text-sky-50 placeholder-sky-200/40 focus:outline-none focus:ring-2 focus:ring-sky-300/70 transition">
    <input name="password" type="password" placeholder="Password" required class="w-full bg-white/10 border border-white/15 rounded-lg px-4 py-2.5 mb-5 text-sky-50 placeholder-sky-200/40 focus:outline-none focus:ring-2 focus:ring-sky-300/70 transition">
    <button type="submit" name="tombol" class="w-full bg-gradient-to-r from-sky-300 to-blue-400 text-slate-900 font-bold rounded-lg py-2.5 shadow-lg shadow-sky-500/30 hover:-translate-y-0.5 hover:brightness-110 active:scale-95 transition">Login</button>
  </form>
</div>

<script>
var s=document.getElementById('stars');
for(var i=0;i<45;i++){var d=document.createElement('i');d.className='dot';var z=Math.random()*2+1;
d.style.cssText='width:'+z+'px;height:'+z+'px;top:'+Math.random()*100+'%;left:'+Math.random()*100+'%;animation-delay:'+Math.random()*3+'s;animation-duration:'+(2+Math.random()*3)+'s';s.appendChild(d);}
</script>
</body>
</html>
