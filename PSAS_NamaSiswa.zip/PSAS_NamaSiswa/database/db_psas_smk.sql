CREATE DATABASE IF NOT EXISTS db_psas_smk
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE db_psas_smk;

CREATE TABLE IF NOT EXISTS tb_users (
  id_user INT(11) NOT NULL AUTO_INCREMENT,
  nama_lengkap VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL,
  PRIMARY KEY (id_user)
) ENGINE=InnoDB;

INSERT INTO tb_users (nama_lengkap, username, password, role) VALUES
('Administrator', 'admin', 'admin123', 'Admin'),
('Pengguna Biasa', 'user', 'user123', 'User');
